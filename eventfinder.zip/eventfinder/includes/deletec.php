<?php
$conn = mysqli_connect('localhost', 'root', '' , 'user') or die ('Unable to connect');
 // gets the id from the url and deletes eventCategory with the id
if (isset($_GET['delete'])){
    $id = $_GET['delete'];
    $conn->query("DELETE FROM eventCategory WHERE id=$id");
    header("location: ../addCategory.php");
}

mysqli_close($conn);
?>

