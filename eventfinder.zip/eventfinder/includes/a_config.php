<?php
	switch ($_SERVER["SCRIPT_NAME"]) { // gets the script name from the url
		case "/eventfinder/events.php": 
			$CURRENT_PAGE = "Events"; //  if $current_page is the events makes event tabs active
			$PAGE_TITLE = "events";
			break;
		case "/eventfinder/login.php":
			$CURRENT_PAGE = "Login"; //  if $current_page is the login makes event tabs active
			$PAGE_TITLE = "login";
			break;
	    case "/eventfinder/admin.php":
				$CURRENT_PAGE = "Admin"; //  if $current_page is the admin makes event tabs active
				$PAGE_TITLE = "admin";
				break;	
	    case "/eventfinder/addCategory.php":
					$CURRENT_PAGE = "Admin"; //  if $current_page is the amdin makes event tabs active
					$PAGE_TITLE = "admin";
					break;	
		default:
			$CURRENT_PAGE = "Index";//  if $current_page is the index makes event tabs active
			$PAGE_TITLE = "home";
	}
?>