<?php
// gets value from the form
 $conn = mysqli_connect('localhost', 'root', '' , 'user') or die ('Unable to connect');
 $ename = mysqli_real_escape_string($conn, $_REQUEST['ename']);
$description = mysqli_real_escape_string($conn, $_REQUEST['description']);
$date = mysqli_real_escape_string($conn, $_REQUEST['date']);
$eventc = mysqli_real_escape_string($conn, $_REQUEST['eventc']);
$state = mysqli_real_escape_string($conn, $_REQUEST['state']);
$featured = mysqli_real_escape_string($conn, $_REQUEST['featured']);


$test = $_FILES["image"]["tmp_name"]; // check if the file field is empty

 // gets the id from the url and updates eventCategory with the id
if($test==NULL){ //if test is empty update without image
    if (isset($_GET['edit'])){
        $id = $_GET['edit'];
        
        $sql =  ("UPDATE events SET ename='$ename',description='$description',date='$date',eventc='$eventc',state='$state' ,featured='$featured' WHERE id = $id");

    }
}else{ //update event with image
$file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
if (isset($_GET['edit'])){
    $id = $_GET['edit'];
    
    $sql =  ("UPDATE events SET ename='$ename',description='$description',date='$date',eventc='$eventc',state='$state' ,featured='$featured',image='$file' WHERE id = $id");

}
}

 if(mysqli_query($conn, $sql)){
    header("Location:../admin.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}
mysqli_close($conn);
?>
