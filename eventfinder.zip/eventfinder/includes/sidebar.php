
    <div class="sidebar">
        <h2>Admin Panel    <i class="fas fa-users-cog"></i></h2>
        <ul>
            <li><a class="active" href="#"><i class="fas fa-futbol"></i>Events</a></li>
            <li><a href="addCategory.php"><i class="fas fa-plus"></i>Event Category</a></li>
            
           
        </ul> 
      
    </div>
    <div class="main_content">
        <div class="header"><i class="fas fa-plus"></i><button type="button">Add Event</button></div>  
        <div class="info">
          
      </div>
    </div>
