<?php
if(!isset($_SESSION['username'])){  // check if user has logged in
    echo '<script type = "text/javascript">';
        
        echo 'window.location.href = "login.php" '; // if not logged sents to login page
        echo '</script>';
}else{
    echo '<script type = "text/javascript">';
        
        echo 'window.location.href = "admin.php" '; // if logged in sents to admin page
        echo '</script>';
}