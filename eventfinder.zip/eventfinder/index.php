<?php include("includes/a_config.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <script src="js/fontawesome.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/card.css">
    <link rel="stylesheet" type="text/css" href="css/slider.css">
    <link rel="stylesheet" href="css/sidebarstyles.css">
    
</head>
<body>

<?php include("includes/navlogin.php");?>
<div class="galleryContainer">
    <div class="slideShowContainer">
        <div id="playPause" onclick="playPauseSlides()"></div>
        <div onclick="plusSlides(-1)" class="nextPrevBtn leftArrow"><span class="arrow arrowLeft"></span></div>
        <div onclick="plusSlides(1)" class="nextPrevBtn rightArrow"><span class="arrow arrowRight"></span></div>
        <div class="captionTextHolder"><p class="captionText slideTextFromTop"></p></div>
      <!-- finds all the events that are featured and enabled from the database and displays in the image slider -->
      <?php
   $connection = mysqli_connect('localhost', 'root', '' , 'user');
    $query1="SELECT * From events WHERE featured='featured' AND state='enable'AND date >= CURDATE() ";
    $query_run1 = mysqli_query($connection,$query1);


  if(mysqli_num_rows($query_run1)>0){
      while($row1=mysqli_fetch_assoc($query_run1))
      {
    ?>
        
        
        <div class="imageHolder">
            <img src="data:image/jpeg;base64,<?php echo base64_encode($row1['image'] ); ?>">1366X768
            <p class="captionText"><?php echo $row1['ename'];?></p>
        </div>
        <?php
      }
  }
  
  ?>
    
    </div>
    <div id="dotsContainer"></div>
</div>
<script src="js/slider.js"></script>
<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 800px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.type {
  color: grey;
  font-size: 22px;
}

.card button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}
</style>

<br>
<br>
<br>
<h1 style="text-align:center"> Upcoming events </h1>
<br>
<br>
<!-- displays all events that are enabled -->
<?php
   $connection = mysqli_connect('localhost', 'root', '' , 'user');
    $query="SELECT * From events WHERE state='enable'AND date >= CURDATE()ORDER BY date ASC";
    $query_run = mysqli_query($connection,$query);


  if(mysqli_num_rows($query_run)>0){
      while($row=mysqli_fetch_assoc($query_run))
      {
    ?>
    <div class="card">
  <img src="data:image/jpeg;base64,<?php echo base64_encode($row['image'] ); ?>" alt="Event_photo" style="width:80%;height: 200px;;"><!-- gets events image from database with the id  -->
  <h1><?php echo $row['ename'];?></h1><!-- gets events name  database with the id  -->
<p class="type"> <?php echo $row['eventc'];?> <?php echo $row['date'];?></p><!-- gets events category and date from database with the id  -->


<p><button onclick="window.location.href ='display.php?display=<?php echo $row['id'];?>';">Details</button></p>
</div>
<br>
<br>
<?php
      }
  }
  else{
      echo "no record found";
  }
  mysqli_close($connection);
  ?>


<?php include("includes/footer.php");?>