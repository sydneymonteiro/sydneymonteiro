function validateForm(){
    let x = document.forms["upevent"]["ename"].value;
    if(x==""){
        alert("Fill in the Event Name"); // if event name field if empty displays alert message
        return false;
    }
    let x1 = document.forms["upevent"]["description"].value;
    if(x1==""){
        alert("Fill in the Event Description"); // if descrpition field if empty displays alert message
        return false;
    }
    let x2 = document.forms["upevent"]["date"].value;
    if(x2==""){
        alert("Enter Date"); // if date field if empty displays alert message
        return false;
    }
    let x3 = document.forms["upevent"]["state"].value;
    if(x3==""){
        alert("Select Event Enable or Disable"); // if state field if empty displays alert message
        return false;
    }
  

}