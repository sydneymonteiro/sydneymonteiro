<?php include("includes/a_config.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <script src="js/fontawesome.js"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/search.css">
    
</head>
<body>

<?php include("includes/navlogin.php");?>
<div class="container">

<form action="search.php">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
</div>

<br>
<br>
<br>

<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 800px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.type {
  color: grey;
  font-size: 22px;
}

.card button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}
</style>
<!-- searchs for the events with event name and category -->
<?php

 $conn = mysqli_connect('localhost', 'root', '' , 'user') or die ('Unable to connect');
 $search = mysqli_real_escape_string($conn, $_REQUEST['search']);

 
 $query="SELECT * FROM events WHERE eventc LIKE '%$search%' OR ename  LIKE '%$search%' ";
    $query_run = mysqli_query($conn,$query);


  if(mysqli_num_rows($query_run)>0){
      while($row=mysqli_fetch_assoc($query_run))
      {
    ?>
    <div class="card">
  <img src="data:image/jpeg;base64,<?php echo base64_encode($row['image'] ); ?>" alt="Event_photo" style="width:80%;height: 200px;;"><!-- gets events image from database with the id  -->
  <h1><?php echo $row['ename'];?></h1><!-- gets events name  database with the id  -->
<p class="type"> <?php echo $row['eventc'];?> <?php echo $row['date'];?></p><!-- gets events category and date from database with the id  -->


<p><button onclick="window.location.href ='display.php?display=<?php echo $row['id'];?>';">Details</button></p>
</div>
<?php
      }
  }
  else{
      echo "no record found";
  }

  mysqli_close($conn);
  ?>




<?php include("includes/footer.php");?>